history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamectl set-hostname TPServer
nano /etc/hosts
nano /etc/hosts
apt-get update
ip a
sync
reboo
reboot
ping -c 3.8.8.8.8
ping -c 3 8.8.8.8
ping -c 3 google.com
apt-get update
localetcl set-keymap us
loadkeys us
dpkg-reconfigure keyboard-configuration
}dpkg
dpkg-reconfigure keyboard-configuration
setupcon
nano /etc/hosts
apt-get update
echo "nameserver 8.8.8.8" > /etc/resolv.conf
ping -c 3 google.com
apt-get -o Acquire::ForceIPv4=true update
cat /etc/resolv.conf
ip route
echo "nameserver 192.168.1.1" > /etc/resolv.conf
ping -c 3 google.com
ping -4 -c 3 google.com
apt-get -o Acquire::ForceIPv4=true update
cat << 'EOF' > /ETC/APT/SOURCES.LIST
deb http://deb.debian.org/debian bullseye main contrib non-free
deb http://deb.debian.org/debian bullseye-updates main contrib non-free
deb http://security.debian.org/debian-security bullseye-security main contrib non-free
EOF

apt-get -o Acquire::ForceIPv4=true update
cat << 'EOF' > /etc/apt/sources.list
deb http://deb.debian.org/debian bullseye main contrib non-free
deb:http://deb.debian.org/debian bullseye-updates main contrib non-free

cat << 'EOF' > /etc/apt/sources.list
deb http://deb.debian.org/debian bullseye main contrib non-free
deb http://deb.debian.org/debian bullseye-updates main contrib non-free
deb http://security.debian.org/debian-security bullseye-security main contrib non-free
EOF

apt-get -o Acquire::ForceIPv4=true update
apt-get -o Acquire::ForceIPv4=true install nano -y
nano /etc/hosts
hostnamectl set-hostname TPServer
reboot
cat /etc/debian_version
apt-get -o Acquire::ForceIPv4=true upgrade -y
cat << 'EOF' > /etc/apt/sources.list
deb http://deb.debian.org/debian bookworm main contrib non-free non-free-firmware
deb http://deb.debian.org/debian bookworm-updates main contrib non-free non-free-firmware
deb http://security.debian.org/debian-security bookworm-security main contrib non-free non-free-firmware
EOF

apt-get -o Acquire::ForceIPv4=true update
apt-get -o Acquire::ForceIPv4=true upgarde -y
apt-get -o Acquire::ForceIPv4=true upgrade -y
apt-get -o Acquire::ForceIPv4=true dist-upgrade -y
reboot
ip route show
cp /etc/network/inerfaces /etc/network/interfaces.bak
cp /etc/network/interfaces /etc/network/interfaces.bak
cat << 'EOF' > /etc/network/interfaces
auto lo
iface lo inet loopback
auto enp0s3
iface enp0s3 inet static
address 192.168.0.200
netmask 255.255.255.0
gateway 192.168.0.1
EOF

echo "nameserver 8.8.8.8" > /etc/resolv.conf
reboot
poweroff
lsblk
fdisk /dev/sdb <<EOF
n
p
1
+3G
n
p
2
+6G
w
EOF

echo -e "label: dos/nsize=3G, type=83/nsize=6G, type=83 \ sfdisk /dev/sdb"
mkfs.ext4 /dev/sdb1
cat << 'EOF' > /tmp/layout.txt
label: dos
size=3G, type=83
size=6G, type=83
EOF

sfdisk /dev/sdb < /tmp?layout.txt
sfdisk /dev/sdb < /tmp/layout.txt
mkfs.ext4 /dev/sdb1
mkfs.ext4 /dev/sdb2
mkdir -p /www_dir
mkdir -p /backup_dir
mount /dev/sdb1 /www_dir
mount /dev/sdb2 /backup_dir
cp -rp /var/www/html/* /www_dir/
chown -R www-data:www-data /www_dir
chmod -R 755 /www_dir
[ ! -f /etc/fstab.bak ] && cp /etc/fstab /etc/fstab.bak
grep -q "/www_dir" /etc/fstab || echo "/dev/sdb1 /www_dir ext4 defaults 0 2" >> /etc/fstab
grep -q "/backup_dir" /etc/fstab || echo "/dev/sdb2 /backup_dir ext4 defaults 0 2" >> /etc/fstab
sed -i 's|DocumentRoot /var/www/html|DocumentRoot /www_dir|g' /etc/apache2/sites-available/000-default.conf
sed -i 's|<Directory /var/www/>|<Directory /www_dir/>|g
EOF
sed -i 's|<Directory /var/www/>|<Directory /www_dir/>|g' /etc/apache2/apache2.conf
systemctl restart apache2
