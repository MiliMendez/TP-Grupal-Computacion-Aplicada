#!/bin/bash
ayuda() {
echo "USO: $0 <origen> <destino>"
echo "EJEMPLO: $0 /var/log /backup_dir"
}

if [ "$1" = "-help" ] ||[ -z "$1" ] || [ -z "$2" ]; then
	ayuda
	exit 0
fi

if [ ! -d "$1" ] || [ ! -d "$2" ]; then
	echo "ERROR: Origen o Destino no validos."
	exit 1
fi


BASE=$(basename "$1")
FECHA=$(date +%Y%m%d)

tar -czf "$2/${BASE}_bkp_${FECHA}.tar.gz" -C "$(dirname "$1")" "$BASE" 
